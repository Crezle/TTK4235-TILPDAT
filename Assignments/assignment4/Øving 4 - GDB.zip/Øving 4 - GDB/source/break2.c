#include <stdio.h>

void library_call(){
	printf("Call from different file\n");
}
