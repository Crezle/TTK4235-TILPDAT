#ifndef BREAK2_H
#define BREAK2_H

void library_call();

#endif
