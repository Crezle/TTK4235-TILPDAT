#include <stdio.h>

int array[200];

int main(){
	for(int i = 0; i < 200; i--){
		array[i] = i;
	}
	return 0;
}
